package models

import (
	"errors"
)

var ErrorRecord = errors.New("Error")

type Snippet struct {
	ID      int
	Title   string
	Content string
}
