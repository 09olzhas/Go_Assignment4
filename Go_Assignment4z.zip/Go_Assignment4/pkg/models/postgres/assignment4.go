package postgres

import (
	"Snippet07/pkg/models"
	"context"
	"github.com/jackc/pgx/v4/pgxpool"
)

const (
	insertSql                 = "INSERT INTO snippets (title,content) VALUES ($1,$2,$3,$4) RETURNING id"
	getSnippetById            = "SELECT id, title, content FROM snippets where id=$1"
)

type SnippetModel struct {
	Pool *pgxpool.pool
}

func (m *SnippetModel) Insert(title,content string) (int, error) {
	var id int

	row := m.Pool.QueryRow(context.Background(), insertSql, title, content)
	error = row.Scan(&id)
	if error != nil {
		return 0, error
	}
	return id, nil
}

func (m *SnippetModel) Get(id int) (*models.Snippet, error) {
	s := &models.Snippet{}
	err := m.Pool.QueryRow(context.Background(), getSnippetById, id).Scan(&s.ID, &s.Title, &s.Content)
	if err != nil {
		if err.Error() == "no result " {
			return nil, models.ErrorRecord
		} else {
			return nil, err
		}
	}
	return s, nil
}

