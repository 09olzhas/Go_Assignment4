package main

import "net/http"

func (app *application) routes() http.Handler {
	var a = http.NewServeMux()
	a.HandleFunc("/", app.home)
	a.HandleFunc("/snippet", app.showSnippet)
	a.HandleFunc("/snippet/create", app.createSnippet)
	fileServer := http.FileServer(http.Dir("./ui/static/"))
	a.Handle("/static/", http.StripPrefix("/static", fileServer))
	return app.logRequest(secureHeaders(a))
}
