package main

import (
	"Snippet07/pkg/models"
	"errors"
	"html/template"
	"net/http"
	"strconv"
)

func (app *application) home(response http.ResponseWriter, request *http.Request) {
	l, error := app.snippets.Latest()
	if error != nil {

		if errors.Is(error, models.ErrNoRecord) {
			app.notFound(response)

		} else {
			app.serverError(response, error)
		}

		return
	}

	if request.URL.Path != "/" {
		app.notFound(response)
		return
	}
	files := []string{
		"./ui/home.page.tmpl",
		"./ui/basic.layout.tmpl",
		"./ui/footer.tmpl",
	}
	ts, error := template.ParseFiles(files...)
	if error != nil {
		app.serverError(response, error)
		return
	}
	error = ts.Execute(response, l)
	if error != nil {
		app.serverError(response, error)
	}

}
func (app *application) showSnippet(response http.ResponseWriter, request *http.Request) {
	id, error := strconv.Atoi(request.URL.Query().Get("id"))
	if id < 1 {
		app.notFound(response)
		return
	}

	l, error := app.snippets.Get(id)
	if error != nil {
		if errors.Is(error, models.ErrorRecord) {
			app.notFound(response)
		} else {
			app.serverError(response, error)
		}
		return
	}
	files := []string{
		"./ui/second.page.tmpl",
		"./ui/basic.layout.tmpl",
		"./ui/footer.tmpl",
	}
	ts, err := template.ParseFiles(files...)
	if err != nil {
		app.serverError(response, err)
		return
	}
	err = ts.Execute(response, l)
	if err != nil {
		app.serverError(response, err)
	}

}
func (app *application) createSnippet(response http.ResponseWriter, request *http.Request) {
	if request.Method != http.MethodPost {
		response.Header().Set("Allow", http.MethodPost)
		app.clientError(response, http.StatusMethodNotAllowed)
		return
	}

}
