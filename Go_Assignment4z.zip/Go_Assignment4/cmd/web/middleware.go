package main

import (
	"fmt"
	"net/http"
)

func secureHeaders(handler http.Handler) http.Handler {

	return http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {

		response.Header().Set("X-XSS-Protection", "1; mode=block")

		response.Header().Set("X-Frame-Options", "deny")

		handler.ServeHTTP(response, request)

	})
}
func (app *application) restorePanic(handler http.Handler) http.Handler {
	return http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
		defer func() {

			if error := recover(); error != nil {
				response.Header().Set("Connection", "close")
				app.serverError(response, fmt.Errorf("%s", error))
			}
		}()
		handler.ServeHTTP(response, request)
	})
}

func (app *application) logRequest(handler http.Handler) http.Handler {
	return http.HandlerFunc(func(response http.ResponseWriter, request *http.Request) {
		app.infoLog.Printf("%s - %s %s %s", request.RemoteAddr, request.Proto, request.Method, request.URL.RequestURI())
		handler.ServeHTTP(response, request)
	})

}

