package main

import (
	"Snippet07/pkg/models/postgres"
	"context"
	"flag"
	"log"
	"net/http"
	"os"
)

type application struct {

	errorLog *log.Logger

	infoLog  *log.Logger

	snippets *postgres.SnippetModel
}

func main() {
	db:= flag.String("db", ":4000", "HTTP network address")
	flag.Parse()
	infoLog := log.New(os.Stdout, "INFO\t", log.Ldate|log.Ltime)
	errorLog := log.New(os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile)
	var pool, err = pgpool.Connect(context.Background(), "user=postgres password=qwerty1234 host=db port=5432 dbname=Snippet07")
	if err != nil {
		log.Fatalf("Error", err)
	}

	app := &application{
		errorLog: errorLog,
		infoLog:  infoLog,
		snippets: &postgres.SnippetModel{Pool: pool},
	}

	server := &http.Server{
		Addr:     *db,
		ErrorLog: errorLog,
		Handler:  app.routes(),
	}
	infoLog.Printf("Starting server on %s", *db)
	err = server.ListenAndServe()
	errorLog.Fatal(err)
}
