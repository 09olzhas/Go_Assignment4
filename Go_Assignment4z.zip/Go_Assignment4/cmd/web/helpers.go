package main

import (
	"fmt"
	"net/http"
	"runtime/debug"
)

func (app *application) serverError(response http.ResponseWriter, error error) {
	track := fmt.Sprintf( error.Error(), debug.Stack())
	app.errorLog.Output(2, track)
	http.Error(response, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
}

func (app *application) notFound(response http.ResponseWriter) {
	app.clientError(response, http.StatusNotFound)
}

func (app *application) clientError(response http.ResponseWriter, status int) {
	http.Error(response, http.StatusText(status), status)
}

